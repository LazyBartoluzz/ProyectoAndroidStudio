package com.example.proyectorestaurante.modelos

data class Plato(
    val id: Long?,
    val descripcion: String?,
    val precio: Double,
    val urlImagen: String?
)