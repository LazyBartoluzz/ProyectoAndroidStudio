package com.example.proyectorestaurante.Screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.proyectorestaurante.modelos.Dato
import com.example.proyectorestaurante.modelos.Orden
import com.example.proyectorestaurante.modelos.RegistroPedido
import com.example.proyectorestaurante.viewModels.BebidasViewModel
import com.example.proyectorestaurante.viewModels.MeserosViewModel
import com.example.proyectorestaurante.viewModels.OrdenesViewModel
import com.example.proyectorestaurante.viewModels.PedidosViewModel
import com.example.proyectorestaurante.viewModels.PlatosEspecialesViewModel
import com.example.proyectorestaurante.viewModels.PlatosViewModel
import java.time.LocalDate
import java.util.Calendar
import java.util.Date
import kotlin.text.toInt


@Composable
fun RegistrarOrden(navController: NavController, pedidosView : PedidosViewModel,bebidaViewModel:BebidasViewModel,meserosView : MeserosViewModel,ordenesView : OrdenesViewModel,platoEspecialViewModel: PlatosEspecialesViewModel,platoViewModel :PlatosViewModel ) {

    val naranjaClaro = Color(0xFFFFA726)
    val azulCielo = Color(0xFF81D4FA)

    var selectedImg1 by remember { mutableStateOf<String?>(null) }
    var expanded1 by remember { mutableStateOf(false) }

    var selectedImg2 by remember { mutableStateOf<String?>(null) }
    var expanded2 by remember { mutableStateOf(false) }

    var selectedImg3 by remember { mutableStateOf<String?>(null) }
    var expanded3 by remember { mutableStateOf(false) }

    var selectedPais by remember { mutableStateOf<String?>(null) }
    var expandedPais by remember { mutableStateOf(false) }

    var numeroMesa by remember { mutableStateOf("1-50") }

    var valor1 by remember { mutableStateOf("0") }
    var valor2 by remember { mutableStateOf("0") }
    var valor3 by remember { mutableStateOf("0") }

// Obtener listas de cada tipo

    //
    val platos by platoViewModel.platos.observeAsState(emptyList())
    val bebidas by bebidaViewModel.bebidas.observeAsState(emptyList())
    val platosEspeciales by platoEspecialViewModel.platosEspeciales.observeAsState(emptyList())
    val losMeseros by meserosView.meseros.observeAsState(emptyList())

    val stockActual by bebidaViewModel.stockActual.observeAsState(0) //variable que al cambiar su valor cambia la UI

    val orden by ordenesView.orden.observeAsState()

    //

    LaunchedEffect(true) {
        platoViewModel.fetchPlatos()
        bebidaViewModel.fetchBebidas()
        platoEspecialViewModel.fetchPlatosEspeciales()
        meserosView.fetchMeseros()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = azulCielo
    ) {

        val elScroll = rememberScrollState()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(elScroll)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Registrar Orden",
                style = MaterialTheme.typography.headlineSmall,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Text("# de ratas = 8", color = Color.White)

            // ----------- Desplegable 1 (PLATO) -------------
            Text("Desplegable 1 - Plato", color = Color.White)
            Box {
                OutlinedButton(
                    onClick = { expanded1 = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Seleccionar imagen de plato")
                }

                DropdownMenu(expanded = expanded1, onDismissRequest = { expanded1 = false }) {
                    platos.forEach { plato ->
                        DropdownMenuItem(
                            text = { Text("Plato") },
                            onClick = {
                                selectedImg1 = plato.urlImagen
                                //idPlato = plato.id

                                pedidosView.idConsumiblePlato.value = plato.id

                                expanded1 = false
                            },
                            leadingIcon = {
                                AsyncImage(
                                    model = plato.urlImagen,
                                    contentDescription = null,
                                    modifier = Modifier.size(32.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        )
                    }
                }
            }
            selectedImg1?.let {
                AsyncImage(
                    model = it,
                    contentDescription = "Imagen Plato Seleccionado",
                    modifier = Modifier.size(64.dp)
                )
            }

            // ----------- Desplegable 2 (BEBIDA) -------------
            Text("Desplegable 2 - Bebida", color = Color.White)
            Box {
                OutlinedButton(
                    onClick = { expanded2 = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Seleccionar imagen de bebida")
                }

                DropdownMenu(expanded = expanded2, onDismissRequest = { expanded2 = false }) {
                    bebidas.forEach { bebida ->
                        DropdownMenuItem(
                            text = { Text("Bebida") },
                            onClick = {
                                selectedImg2 = bebida.urlImagen
                                //idBebida = bebida.id

                                pedidosView.idConsumibleBebida.value = bebida.id
                                expanded2 = false
                            },
                            leadingIcon = {
                                AsyncImage(
                                    model = bebida.urlImagen,
                                    contentDescription = null,
                                    modifier = Modifier.size(32.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        )
                    }
                }
            }
            selectedImg2?.let {
                AsyncImage(
                    model = it,
                    contentDescription = "Imagen Bebida Seleccionada",
                    modifier = Modifier.size(64.dp)
                )
            }

            // ----------- Desplegable 3 (PLATO ESPECIAL) -------------
            Text("Desplegable 3 - Plato Especial", color = Color.White)
            Box {
                OutlinedButton(
                    onClick = { expanded3 = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Seleccionar imagen de especial")
                }

                DropdownMenu(expanded = expanded3, onDismissRequest = { expanded3 = false }) {
                    platosEspeciales.forEach { especial ->
                        DropdownMenuItem(
                            text = { Text("Especial") },
                            onClick = {
                                selectedImg3 = especial.urlImagen
                                //idPlatoEspecial = especial.id

                                pedidosView.idConsumibleEspecial.value = especial.id

                                expanded3 = false
                            },
                            leadingIcon = {
                                AsyncImage(
                                    model = especial.urlImagen,
                                    contentDescription = null,
                                    modifier = Modifier.size(32.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        )
                    }
                }
            }
            selectedImg3?.let {
                AsyncImage(
                    model = it,
                    contentDescription = "Imagen Especial Seleccionado",
                    modifier = Modifier.size(64.dp)
                )
            }

            // Dropdown de países
            Text("nombres Meseros", color = Color.White)
            Box {
                OutlinedButton(
                    onClick = { expandedPais = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(selectedPais ?: "Seleccionar país")
                }

                DropdownMenu(expanded = expandedPais, onDismissRequest = { expandedPais = false }) {
                    losMeseros.forEach { pais ->
                        DropdownMenuItem(
                            text = { Text(pais.nombre?:"") },
                            onClick = {
                                selectedPais = pais.nombre
                                expandedPais = false
                            }
                        )
                    }
                }
            }

            // Mini formulario para ingresar los tres valores
            TextField(
                value = numeroMesa,
                onValueChange = { numeroMesa = it },
                label = { Text("# mesa") },
                modifier = Modifier.fillMaxWidth()
            )



            TextField(
                value = valor1,
                onValueChange = { valor1 = it },
                label = { Text("Valor 1") },
                modifier = Modifier.fillMaxWidth()
            )

            TextField(
                value = valor2,
                onValueChange = { valor2 = it },
                label = { Text("Valor 2") },
                modifier = Modifier.fillMaxWidth()
            )

            TextField(
                value = valor3,
                onValueChange = { valor3 = it },
                label = { Text("Valor 3") },
                modifier = Modifier.fillMaxWidth()
            )

            val contextoParaToast = LocalContext.current.applicationContext

            Button(onClick = {

                //plato
                //bebida
                //especial

                bebidaViewModel.fetchStockActual( pedidosView.idConsumibleBebida.value ?:0 )

                if( (stockActual - valor2.toInt()) < 0 ){

                    Toast.makeText( contextoParaToast, "No hay suficientes bebidas!", Toast.LENGTH_LONG ).show()
                } else {

                    val idMesero : Long? = pedidosView.idMesero.value

                    if((numeroMesa.toInt() >= 1 && numeroMesa.toInt() <= 50) && idMesero != null){

                        val calendar = Calendar.getInstance()

// Convertir Calendar a java.sql.Date (solo la parte de la fecha, sin hora)
                        val fechaActual = Date(calendar.timeInMillis)

                        //val fechaActual = LocalDate.now()

                        val cantidadPlato = valor1

                        val cantidadBebida = valor2

                        val cantidadEspecial = valor3

                        val idEspecial : Long?=pedidosView.idConsumibleEspecial.value

                        val idPlato : Long?=pedidosView.idConsumiblePlato.value

                        val idBebida : Long?=pedidosView.idConsumibleBebida.value

                        val nuevaOrden = Orden( null,fechaActual.toString() ,numeroMesa.toInt(),idEspecial,idPlato,idMesero,idBebida)

                        val listaObservable=pedidosView.pedidos

                        val registro : RegistroPedido = listaObservable.get( numeroMesa .toInt()- 1 )
                        if ( registro.fecha != "" ){

                            registro.fecha = fechaActual.toString()
                        }
                        val listaPlatos = registro.platos
                        val listaBebidas = registro.bebidas
                        val listaPlatosEspeciales = registro.platosEspeciales

                        var bandPlatos: Boolean = false
                        var bandBebidas: Boolean = false
                        var bandPlatosEspeciales: Boolean = false

                        if( idPlato != null  && cantidadPlato.toInt() > 0  ){
                            for (item in listaPlatos) {
                                if (item.id == idPlato.toInt()) {

                                    item.cantidad += cantidadPlato.toInt()
                                    bandPlatos = true
                                    break
                                }
                            }
                        }

                        if( idBebida != null && cantidadBebida.toInt() > 0 ){
                            for (item in listaBebidas) {
                                if (item.id == idBebida.toInt()) {

                                    item.cantidad += cantidadBebida.toInt()
                                    bandBebidas = true
                                    break
                                }
                            }
                        }

                        if( idEspecial != null && cantidadEspecial.toInt() > 0 ){
                            for (item in listaPlatosEspeciales) {
                                if (item.id == idEspecial.toInt()) {

                                    item.cantidad += cantidadEspecial.toInt()
                                    bandPlatosEspeciales = true
                                    break
                                }
                            }
                        }


                        if( !bandPlatos && idPlato != null && cantidadPlato.toInt() > 0 ){

                            val datoPlato : Dato = Dato( idPlato.toInt(),cantidadPlato .toInt())
                            registro.platos.add(datoPlato)
                        }
                        if( !bandBebidas && idBebida != null && cantidadBebida .toInt()> 0){

                            val datoBebida : Dato = Dato( idBebida.toInt(),cantidadBebida .toInt())

                            registro.bebidas.add(datoBebida)

                        }
                        if( !bandPlatosEspeciales && idEspecial != null && cantidadEspecial .toInt()> 0 ){

                            val datoPlatoEspecial : Dato = Dato( idEspecial.toInt(),cantidadEspecial.toInt() )
                            registro.platosEspeciales.add(datoPlatoEspecial)
                        }

                        pedidosView.idOrden.value = ordenesView.createOrden( nuevaOrden )

                        Toast.makeText( contextoParaToast, "Orden marcada!", Toast.LENGTH_SHORT ).show()

                        pedidosView.idConsumibleEspecial .value = null

                        pedidosView.idConsumiblePlato .value = null

                        pedidosView.idConsumibleBebida .value = null

                        pedidosView.cantidadPlatos .value = valor1.toInt()
                        pedidosView.cantidadBebidas .value = valor2.toInt()
                        pedidosView.cantidadEspeciales.value  = valor3.toInt()

                        valor1 = "0"
                        valor2 = "0"
                        valor3 = "0"

                    }else{

                        Toast.makeText( contextoParaToast, "No existen esas mesas! o No hay mesero asignado!", Toast.LENGTH_LONG ).show()

                    }

                }


            }) {
                Text("Hacer orden")
            }

            Button(onClick = {

                if( pedidosView.idOrden.value != null ){

                    //me voy a ir...
                    //retrocedo con los cambios a la estructura de datos

                    //-----------
                    pedidosView.cantidadPlatos.value  = valor1.toInt()
                    pedidosView.cantidadBebidas .value = valor2.toInt()
                    pedidosView.cantidadEspeciales.value  = valor3.toInt()

                    ordenesView.fetchOrdenById( pedidosView.idOrden.value?:0 )

                    val numeroMesa : Int? = orden?.numeroMesa

                    val cantidadPlato:Int? = pedidosView.cantidadPlatos.value

                    val cantidadBebida :Int?= pedidosView.cantidadBebidas.value

                    val cantidadEspecial :Int?= pedidosView.cantidadEspeciales.value

                    val idEspecial : Long?=orden?.idPlatoEspecial

                    val idPlato : Long?=orden?.idPlatos

                    val idBebida : Long?=orden?.idBebida


                    //---
                    val listaObservable=pedidosView.pedidos

                    val registro : RegistroPedido = listaObservable.get( (  (numeroMesa?.toInt()) ?: 0 )-1 )

                    val listaPlatos = registro.platos
                    val listaBebidas = registro.bebidas
                    val listaPlatosEspeciales = registro.platosEspeciales

                    //oooooooooooooooooooooooooooooooo

                    var i :Int

                    i =0
                    if( idPlato != null  && cantidadPlato?.toInt()!! > 0  ){
                        for (item in listaPlatos) {
                            if (item.id == idPlato.toInt()) {

                                item.cantidad -= cantidadPlato

                                break
                            }
                            i++
                        }
                        if( listaPlatos.get(idPlato.toInt()  ).cantidad == 0 ){
                            listaPlatos.removeAt(i)
                        }
                    }

                    i =0
                    if( idBebida != null && cantidadBebida?.toInt()!! > 0 ){
                        for (item in listaBebidas) {
                            if (item.id == idBebida.toInt()) {

                                item.cantidad -= cantidadBebida

                                break
                            }
                            i++
                        }

                        if( listaBebidas.get(idBebida.toInt()).cantidad == 0 ){
                            listaBebidas.removeAt(i)
                        }

                    }

                    i = 0
                    if( idEspecial != null && cantidadEspecial?.toInt()!! > 0 ){

                        for (item in listaPlatosEspeciales) {
                            if (item.id == idEspecial.toInt()) {

                                item.cantidad -= cantidadEspecial

                                break
                            }
                            i++
                        }

                        if( listaPlatosEspeciales.get(idEspecial.toInt()).cantidad == 0 ){
                            listaPlatosEspeciales.removeAt(i)
                        }
                    }

                    //oooooooooooooooooooooooooooooooo

                    //--------------------

                    navController.navigate("ScreenL")
                }else{

                    Toast.makeText( contextoParaToast, "No existe una orden para modificar!", Toast.LENGTH_LONG ).show()

                }

            }) {
                Text("Modificar la orden")
            }

            Button(onClick = {

                val mesero = losMeseros.find { it.nombre.equals(selectedPais, ignoreCase = true) }
                pedidosView.idMesero .value= mesero?.id
            }) {
                Text("Cambiar mesero")
            }

            Button(
                onClick = { navController.navigate("ScreenA") },
                colors = ButtonDefaults.buttonColors(containerColor = naranjaClaro),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ir al inicio", color = Color.White)
            }
        }
    }
}

