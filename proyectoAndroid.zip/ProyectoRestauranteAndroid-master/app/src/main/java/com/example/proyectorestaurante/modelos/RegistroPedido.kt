package com.example.proyectorestaurante.modelos

data class RegistroPedido(
    var fecha: String="",
    val platos: MutableList<Dato> = mutableListOf(),
    val bebidas: MutableList<Dato> = mutableListOf(),
    val platosEspeciales: MutableList<Dato> = mutableListOf()
)