package com.example.proyectorestaurante.Screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.proyectorestaurante.viewModels.BebidasViewModel
import com.example.proyectorestaurante.viewModels.PedidosViewModel
import com.example.proyectorestaurante.viewModels.PlatosEspecialesViewModel
import com.example.proyectorestaurante.viewModels.PlatosViewModel
@Composable
fun PasadizoModificar(
    navController: NavController,
    pedidosView: PedidosViewModel,
    platos: PlatosViewModel,
    bebidas: BebidasViewModel,
    especiales: PlatosEspecialesViewModel
) {
    // Estados para los campos
    var number1 by remember { mutableStateOf("") }
    var number2 by remember { mutableStateOf("") }
    var number3 by remember { mutableStateOf("") }

    var number4 by remember { mutableStateOf("") }
    var number5 by remember { mutableStateOf("") }
    var number6 by remember { mutableStateOf("") }

    val lightOrange = Color(0xFFFFE0B2)
    val skyBlue = Color(0xFF87CEEB)

    Column(modifier = Modifier.fillMaxSize()) {

        // 🔶 Primer Box: Cambiar consumibles
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(lightOrange, skyBlue)))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Eliminación de Consumibles",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Button(onClick = {
                            pedidosView.idConsumible.value = number1.toLongOrNull()
                            navController.navigate("ScreenE")
                        }) {
                            Text("Cambiar plato")
                        }
                        Button(onClick = {
                            pedidosView.idConsumible.value = number2.toLongOrNull()
                            navController.navigate("ScreenF")
                        }) {
                            Text("Cambiar bebida")
                        }
                        Button(onClick = {
                            pedidosView.idConsumible.value = number3.toLongOrNull()
                            navController.navigate("ScreenG")
                        }) {
                            Text("Cambiar plato especial")
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        NumberInputField(value = number1, onValueChange = { number1 = it }, label = "Id plato")
                        NumberInputField(value = number2, onValueChange = { number2 = it }, label = "Id bebida")
                        NumberInputField(value = number3, onValueChange = { number3 = it }, label = "Id plato especial")
                    }
                }
            }
        }

        // 🔷 Segundo Box: Borrar consumibles
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(lightOrange, skyBlue)))
                .padding(16.dp)
        ) {
            val contextoParaToast = LocalContext.current.applicationContext

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Button(onClick = {
                            number4.toLongOrNull()?.let {
                                platos.deletePlato(it)
                                Toast.makeText(contextoParaToast, "Se ha borrado ese plato con ID $it", Toast.LENGTH_SHORT).show()
                            } ?: Toast.makeText(contextoParaToast, "ID inválido", Toast.LENGTH_LONG).show()
                        }) {
                            Text("Borrar plato")
                        }
                        Button(onClick = {
                            number5.toLongOrNull()?.let {
                                bebidas.deleteBebida(it)
                                Toast.makeText(contextoParaToast, "Se ha borrado esa bebida con ID $it", Toast.LENGTH_SHORT).show()
                            } ?: Toast.makeText(contextoParaToast, "ID inválido", Toast.LENGTH_LONG).show()
                        }) {
                            Text("Borrar bebida")
                        }
                        Button(onClick = {
                            number6.toLongOrNull()?.let {
                                especiales.deletePlatoEspecial(it)
                                Toast.makeText(contextoParaToast, "Se ha borrado ese plato especial con ID $it", Toast.LENGTH_SHORT).show()
                            } ?: Toast.makeText(contextoParaToast, "ID inválido", Toast.LENGTH_LONG).show()
                        }) {
                            Text("Borrar plato especial")
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        NumberInputField(value = number4, onValueChange = { number4 = it }, label = "Id plato")
                        NumberInputField(value = number5, onValueChange = { number5 = it }, label = "Id bebida")
                        NumberInputField(value = number6, onValueChange = { number6 = it }, label = "Id plato especial")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { navController.navigate("ScreenA") },

                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Volver", color = Color.White)
                }
            }
        }
    }
}


@Composable
fun NumberInputField(value: String, onValueChange: (String) -> Unit, label: String) {
    TextField(
        value = value,
        onValueChange = { newValue ->
            // Acepta solo enteros
            if (newValue.all { it.isDigit() }) {
                onValueChange(newValue)
            } else if (newValue.isEmpty()) {
                onValueChange("") // permite borrar
            }
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.width(150.dp)
    )
}
