package com.example.proyectorestaurante

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.example.proyectorestaurante.Screens.Main
import com.example.proyectorestaurante.viewModels.PedidosViewModel
import com.example.proyectorestaurante.viewModels.BebidasViewModel
import com.example.proyectorestaurante.viewModels.MeserosViewModel
import com.example.proyectorestaurante.viewModels.OrdenesViewModel
import com.example.proyectorestaurante.viewModels.PlatosEspecialesViewModel
import com.example.proyectorestaurante.viewModels.PlatosViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        //creo las listas y la estructura de datos

        val pedidosViewModel = ViewModelProvider(this)[PedidosViewModel::class.java]

        val  bebidasViewModel = ViewModelProvider(this).get(BebidasViewModel::class.java)
        val  meserosViewModel = ViewModelProvider(this).get(MeserosViewModel::class.java)
        val ordenesViewModel = ViewModelProvider(this).get(OrdenesViewModel::class.java)
        val  platosEspecialesViewModel = ViewModelProvider(this).get(PlatosEspecialesViewModel::class.java)
        val   platosViewModel = ViewModelProvider(this).get(PlatosViewModel::class.java)

        setContent {

            Main( pedidosViewModel, bebidasViewModel,meserosViewModel,ordenesViewModel,platosEspecialesViewModel,platosViewModel)
        }
    }
}
