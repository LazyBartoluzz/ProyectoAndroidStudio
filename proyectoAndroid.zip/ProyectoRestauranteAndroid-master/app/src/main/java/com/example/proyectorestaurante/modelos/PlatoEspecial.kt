package com.example.proyectorestaurante.modelos

data class PlatoEspecial(
    val id: Long?,
    val descripcion: String?,
    val esExotico: Boolean?,
    val precio: Double?,
    val urlImagen: String?
)