package com.example.proyectorestaurante.modelos

data class Dato(
    val id: Int,
    var cantidad: Int = 0
)