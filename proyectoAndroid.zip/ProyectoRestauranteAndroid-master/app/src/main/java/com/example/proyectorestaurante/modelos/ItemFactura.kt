package com.example.proyectorestaurante.modelos

data class ItemFactura(
    val tipo: String,
    val nombre: String,
    val cantidad: Int,
    val precio: Double,
    val monto: Double
)