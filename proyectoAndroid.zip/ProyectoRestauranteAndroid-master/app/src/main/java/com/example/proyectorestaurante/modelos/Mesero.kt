package com.example.proyectorestaurante.modelos

data class Mesero(
    val id: Long?,
    val nombre: String?
)