package com.example.proyectorestaurante.viewModels

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.ViewModel
import com.example.proyectorestaurante.modelos.Dato
import com.example.proyectorestaurante.modelos.RegistroPedido

import androidx.compose.runtime.remember


class PedidosViewModel : ViewModel() {

    // Lista observable para Jetpack Compose (opcional pero recomendable)
    val pedidos: SnapshotStateList<RegistroPedido> = mutableStateListOf()

    var idMesero = mutableStateOf<Long?>(null)

    var idConsumiblePlato = mutableStateOf<Long?>(null)
    var idConsumibleBebida =mutableStateOf<Long?>(null)
    var idConsumibleEspecial =mutableStateOf<Long?>(null)
    var idConsumible = mutableStateOf<Long?>(null)

    var idOrden =mutableStateOf<Long?>(null)

    var cantidadPlatos =mutableStateOf<Int?>(null)
    var cantidadBebidas =mutableStateOf<Int?>(null)
    var cantidadEspeciales = mutableStateOf<Int?>(null)

    init {
        // Inicializar con 50 pedidos vacíos
        repeat(50) {
            pedidos.add(
                RegistroPedido(
                    "",
                    mutableListOf<Dato>(),
                    mutableListOf<Dato>(),
                    mutableListOf<Dato>()
                )
            )
        }
    }

    // Ejemplo: actualizar un pedido en cierta posición
    fun actualizarPedido(index: Int, nuevoPedido: RegistroPedido) {
        if (index in pedidos.indices) {
            pedidos[index] = nuevoPedido
        }
    }

    // Obtener un pedido específico
    fun obtenerPedido(index: Int): RegistroPedido? {
        return pedidos.getOrNull(index)
    }
}